    </div>
  </div>
  <div id="footer"><div id="footer_box"><span>Powered by <a href="http://haow.in/blogmi/" target="_blank">BlogMi</a></span></div></div>
</body>
</html>