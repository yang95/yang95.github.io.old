<?php
$mc_config = array (
  'site_link' => 'http://127.0.0.1',
  'site_name' => '博客迷',
  'site_desc' => '不需要数据库的迷你博客程序',
  'user_name' => 'admin',
  'user_pass' => '2046',
  'user_nick' => 'BlogMi',
  'comment_code' => '',
)
?>