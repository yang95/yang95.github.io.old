<?php
$mc_pages=array (
  'contact' => 
  array (
    'file' => 's2wxjs',
    'path' => 'contact',
    'state' => 'publish',
    'title' => '联系方式',
    'date' => '2012-03-30',
    'time' => '01:25:45',
    'can_comment' => '0',
  ),
)
?>