<?php
$mc_posts=array (
  'pxvczn' => 
  array (
    'id' => 'pxvczn',
    'state' => 'publish',
    'title' => 'Hello，World！',
    'tags' => 
    array (
      0 => '妙语',
      1 => '男人',
      2 => '女人',
    ),
    'date' => '2012-04-05',
    'time' => '10:10:10',
    'can_comment' => '1',
  ),
)
?>