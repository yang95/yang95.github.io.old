<?php

define('PRIVATE_KEY', 'crawlerpic');

echo shell_exec("git pull");